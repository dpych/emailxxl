
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","appLoader()"],["c","Controller"],["c","Controller_Api"],["c","Controller_Desc"],["c","Controller_Main"],["c","Controller_Salons"],["c","Controller_Shops"],["c","Files"],["f","frameworkLoader()"],["f","main()"],["c","Model"],["c","Model_Auth"],["c","Model_CSV"],["c","Model_Products"],["c","Model_Salons"],["c","Model_Shops"],["c","Model_SizeerCom"],["c","Model_Sqlite"],["c","Model_XML"],["c","ProductsEmail"],["c","View"],["c","Zip"]];
